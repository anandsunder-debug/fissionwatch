// Safe non-reactive external-flow surrogate
// Dimensions are assumed from user input, not video-verified.
// Units: millimeters
$fn = 96;

// Cylindrical surrogate, axis along X
rotate([0, 90, 0])
    cylinder(h = 100.0, r = 1.5, center = false);
